# System Architecture - Visual Guide

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    TRAFFIC VIOLATION SYSTEM                      │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐
│ TrafficSensor│  Generates batches of vehicles (10-15 cars)
│  (3s interval│  Every 3 seconds
└──────┬───────┘
       │
       ↓
┌──────────────────────────────────────────┐
│    QueuedCarProcessor (Main Engine)      │
│   ├─ Add vehicles to queue               │
│   ├─ Manage 5 concurrent workers         │
│   ├─ Emit callbacks                      │
│   └─ Track statistics                    │
└──────┬───────────────────────────────────┘
       │
       ├─────────────────────────────────────┐
       │                                     │
       ↓                                     ↓
   [Queue]                          [5 Worker Threads]
  10-15 Cars    ◄─ Pull cars ────►    Each checks a car
                                     in parallel
       │                                     │
       │                                     ↓
       │                            [Check Individual Car]
       │                            ├─ Speed check
       │                            ├─ Calculate fine
       │                            └─ Return verdict
       │                                     │
       └──────────────────────────────────────┘
              ↓
     [Return Verdict Callbacks]
     [SAFE] or [VIOLATION] with fine
              │
              ↓
     ┌─────────────────────┐
     │  Output Channels    │
     ├─────────────────────┤
     │ 1. Console logs     │ [CHECK], [SAFE], [VIOLATION]
     │ 2. GUI Display      │ Real-time status panel
     │ 3. Data files       │ traffic_data.json, tickets.json
     └─────────────────────┘
```

---

## Data Flow Diagram

```
SENSOR                PROCESSOR                 RESULTS
  │                      │                        │
  ├─ Car 1               │                        │
  ├─ Car 2               │                        │
  ├─ Car 3         ┌─────▼──────────────────┐    │
  ├─ Car 4         │ QueuedCarProcessor     │    │
  ├─ Car 5    ────►│                        │    │
  ├─ Car 6         │  Queue [5 Cars]        │    │
  ├─ Car 7         │                        │    │
  ├─ Car 8    Add  │  Worker 1 → Car 1 ────┤────► [SAFE]
  ├─ Car 9         │  Worker 2 → Car 2 ────┤────► [VIOLATION] $50
  ├─ Car 10        │  Worker 3 → Car 3 ────┤────► [SAFE]
  │                │  Worker 4 → Car 4 ────┤────► [VIOLATION] $30
  │ (more...)      │  Worker 5 → Car 5 ────┤────► [SAFE]
  │                │                        │
  │                │  After 100-200ms       │
  │                │  Workers get next cars │
  │                │                        │
  │                │  Car 6 → [VIOLATION]   │────► $75
  │                │  Car 7 → [SAFE]        │────► OK
  │                │  ...continues...       │
  │                │                        │
  │                │  [COMPLETE BATCH]      │────► Signal
  │                └────────────────────────┘
```

---

## Concurrent Processing Timeline

```
TIME PROGRESS
 ↓

 0ms   [Batch arrives: 10 cars]
       └─ Add to queue

 10ms  [Workers start]
       Worker 1: Car 1 ▓░░░░░░░░░░░░░░░░░░░░░░░░░ (100-200ms)
       Worker 2: Car 2 ▓░░░░░░░░░░░░░░░░░░░░░░░░░
       Worker 3: Car 3 ▓░░░░░░░░░░░░░░░░░░░░░░░░░
       Worker 4: Car 4 ▓░░░░░░░░░░░░░░░░░░░░░░░░░
       Worker 5: Car 5 ▓░░░░░░░░░░░░░░░░░░░░░░░░░

110ms  Car 1 complete → [SAFE]
       Worker 1: Car 6 ▓░░░░░░░░░░░░░░░░░░░░░░░░░

120ms  Car 2 complete → [VIOLATION] $50
       Worker 2: Car 7 ▓░░░░░░░░░░░░░░░░░░░░░░░░░

130ms  Car 3 complete → [SAFE]
       Worker 3: Car 8 ▓░░░░░░░░░░░░░░░░░░░░░░░░░

140ms  Car 4 complete → [VIOLATION] $30
       Worker 4: Car 9 ▓░░░░░░░░░░░░░░░░░░░░░░░░░

150ms  Car 5 complete → [SAFE]
       Worker 5: Car 10 ▓░░░░░░░░░░░░░░░░░░░░░░░░

...

300ms  Car 10 complete → [VIOLATION] $60

       [BATCH COMPLETE] - 10 cars done, 4 violations
       Average time: ~30ms per car (with parallelism)
```

---

## Class Architecture

```
┌──────────────────────────────────┐
│  QueuedCarProcessor              │
├──────────────────────────────────┤
│ Properties:                      │
│  - car_queue: Queue              │
│  - executor: ThreadPoolExecutor  │
│  - num_workers: 5                │
│  - total_processed: int          │
│  - total_violations: int         │
├──────────────────────────────────┤
│ Methods:                         │
│  - start()                       │
│  - stop()                        │
│  - add_vehicles(list)            │
│  - _main_loop()                  │
│  - _check_car(vehicle)           │
│  - get_stats()                   │
├──────────────────────────────────┤
│ Callbacks:                       │
│  - on_car_checking()             │
│  - on_car_checked()              │
│  - on_batch_complete()           │
└──────────────────────────────────┘
                 △
                 │
                 │
         Uses ───┴──► CarCheckResult
                         ├─ vehicle
                         ├─ is_violation
                         ├─ violation_type
                         ├─ ticket
                         └─ check_timestamp
```

---

## GUI Display Architecture

```
┌─────────────────────────────────────────────────────┐
│           Traffic Simulation GUI                     │
├─────────────────────────────────────────────────────┤
│                                                     │
│ ┌──────────────────┐  ┌──────────────────────────┐ │
│ │ LEFT PANEL       │  │ RIGHT PANEL              │ │
│ │ (Controls)       │  │ (Violations Table)       │ │
│ │                  │  │                          │ │
│ │ [Mulai]  [Stop]  │  │ Plat │ Pemilik │ Denda  │ │
│ │ [Clear]          │  │ ──────────────────────── │ │
│ │                  │  │ ABC..│ John Doe│ 775K... │ │
│ │ ┌──────────────┐ │  │ XYZ..│ Jane D. │ 620K... │ │
│ │ │ Statistics   │ │  │                          │ │
│ │ │              │ │  │                          │ │
│ │ │ Violations:0 │ │  └──────────────────────────┘ │
│ │ │ Vehicles: 10 │ │                                │
│ │ │ Denda: 0Rp   │ │                                │
│ │ │              │ │                                │
│ │ └──────────────┘ │                                │
│ │                  │                                │
│ │ ┌──────────────┐ │                                │
│ │ │[CHECK] Status│ │                                │
│ │ │              │ │                                │
│ │ │ Plat: ABC124 │ │                                │
│ │ │ Owner: John  │ │                                │
│ │ │ Speed: 85km  │ │                                │
│ │ │ Status: VIOL │ │  ▲                            │
│ │ │              │ │  │ Auto-refresh               │
│ │ │[QUEUE]Status:│ │  │ every 500ms                │
│ │ │ 3 waiting    │ │  │                            │
│ │ │              │ │  │                            │
│ │ │[RESULT]Last: │ │  │                            │
│ │ │ VIOLATION    │ │  │                            │
│ │ │ Fine: 775Rp  │ │  │                            │
│ │ │              │ │  │                            │
│ │ │[INFO]5 sensors│ │  │                            │
│ │ │ concurrent   │ │  │                            │
│ │ └──────────────┘ │                                │
│ │                  │                                │
│ └──────────────────┘                                │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## Processing States

```
                    START
                      │
                      ↓
            [Waiting for Vehicles]
                      │
        Vehicles added to queue
                      │
                      ↓
            [Processing Queue]
         (5 workers active)
                      │
        ┌─────────────┼─────────────┐
        ↓             ↓             ↓
    [Worker 1]   [Worker 2]   [Worker 3...]
      Check       Check         Check
      Car 1       Car 2         Car 3
        │             │             │
        └─────────────┼─────────────┘
                      ↓
              [Results Ready]
        [SAFE] or [VIOLATION]
                      │
                      ↓
            [Callback Emitted]
              on_car_checked
                      │
                      ↓
       [Workers get next cars]
       OR [Queue empty]
                      │
                      ↓
            [Batch Complete]
            on_batch_complete
                      │
                      ↓
            [Waiting for next batch]
```

---

## Callback Flow

```
QueuedCarProcessor                     Callbacks
     │                                     │
     ├─ on_car_checking(vehicle)          │
     │  └─ Called when checking starts────► logger.info("[CHECK]...")
     │                                     gui.current_vehicle_label
     │
     ├─ on_car_checked(result)            │
     │  └─ Called with verdict ──────────► logger.warning("[VIOLATION]")
     │                                     logger.info("[SAFE]")
     │                                     gui.last_verdict_label
     │
     └─ on_batch_complete(vehicles, violations)
        └─ Called when batch done ──────► logger.info("[COMPLETE]")
                                          gui.refresh_violations_table
```

---

## Real-time GUI Update Cycle

```
AUTO_REFRESH Timer (every 500ms)
     │
     ├─ Read traffic_data.json
     ├─ Read tickets.json
     │
     ├─ Update violation count
     ├─ Update vehicle count
     │
     ├─ Show current car (last in vehicles)
     ├─ Calculate queue size (vehicles - violations)
     ├─ Show last verdict
     │
     ├─ Update statistics:
     │  ├─ Total violations
     │  ├─ Total fines (IDR)
     │  ├─ Avg speed
     │  └─ Max speed
     │
     └─ Refresh violations table
        └─ Show top violations
```

---

## Performance Characteristics

```
Sequential Processing:
  Car 1: ▓ [SAFE]
  Car 2: ▓ [VIOLATION]
  Car 3: ▓ [SAFE]
  Time: ~300ms per car

Concurrent Processing (5 workers):
  Cars 1-5 in parallel
  Car 1:  ▓░░░░░░░░░░░░░░░░░░░░░░░░
  Car 2:  ░▓░░░░░░░░░░░░░░░░░░░░░░
  Car 3:  ░░▓░░░░░░░░░░░░░░░░░░░░░░
  Car 4:  ░░░▓░░░░░░░░░░░░░░░░░░░░░░
  Car 5:  ░░░░▓░░░░░░░░░░░░░░░░░░░░░░
  Time: ~300ms for 5 cars = 60ms per car (5x faster!)
```

---

This completes the smooth sequential car processing implementation! 🎉
